# EpamPEPTask4
As we can't run java Program without main class in above java 1.8
To run the particular Application we need to have Java version less than 1.8
